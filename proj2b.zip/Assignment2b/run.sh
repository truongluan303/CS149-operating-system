gcc summatrix_parallel.c -o main.exe

./main.exe matrix.txt morematrix.txt 4

FILE=main.exe
if [ -f "$FILE" ]; then
    rm main.exe
fi