gcc summatrix_parallel.c -o summatrix_parallel.exe -Wall -Werror

./summatrix_parallel.exe matrix.txt morematrix.txt 4

rm summatrix_parallel.exe